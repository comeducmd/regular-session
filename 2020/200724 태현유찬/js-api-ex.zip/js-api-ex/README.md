# js-api-ex
⚙️ JavaScript를 이용한 오픈 API 활용 연습
